-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Bulan Mei 2024 pada 12.34
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental_motor`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) DEFAULT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `noHp` int(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `email`, `noHp`, `password`) VALUES
(NULL, 'Wahyu', 'admin', 'admin@gmail.com', 1234, 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `datamotor`
--

CREATE TABLE `datamotor` (
  `id` int(11) NOT NULL,
  `noPlat` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `merek` varchar(50) NOT NULL,
  `tahun` int(50) NOT NULL,
  `warna` varchar(50) NOT NULL,
  `transmisi` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `datamotor`
--

INSERT INTO `datamotor` (`id`, `noPlat`, `nama`, `merek`, `tahun`, `warna`, `transmisi`, `harga`) VALUES
(2, 'H 1 TAM', 'Icikiwir', 'Honda', 2018, 'Karat', 'Manual', 5000000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `noHp` int(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `konfimpass` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `img` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama`, `noHp`, `email`, `pass`, `konfimpass`, `username`, `img`) VALUES
(1, 'dodi', 12412, 'd@gmail.com', 'dodi12', 'dodi12', 'ddi', ''),
(3, 'yfcfy', 1251261, 'do@gmail.com', '123456', '123456', 'dodi', 0x443a47726f7570203236302e706e67),
(4, 'russ', 981876, 'd@gmail.com', '12345', '12345', 'rudi', ''),
(5, 'ucok', 69696969, 'ucokocok@entadentod.com', '831167d1d11e16b877055beb00ffec4b', 'memek', 'kocok', 0x433a55736572730d616b616e446f776e6c6f6164734b656c6f6d706f6b2032302e706e67);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `datamotor`
--
ALTER TABLE `datamotor`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `datamotor`
--
ALTER TABLE `datamotor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
